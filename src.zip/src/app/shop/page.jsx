import Navbar from "@/components/Navbar";

export default function Shop() {
  return (
    <div>
      <Navbar />
      Shop
    </div>
  );
}
